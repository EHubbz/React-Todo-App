import React from "react";
import "./Header.css";

const header = () => {
  return <h1>Today's To-Do List</h1>;
};

export default header;
